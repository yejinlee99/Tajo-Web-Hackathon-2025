window.onload = function() {
    alert("📢 JS 로드 완료!");
};